package java.lang

import org.allbinary.logic.string.StringUtil
import kotlin.reflect.KClass

open class Object  {

    var javaClass: Class<Any> = Class()

    @Throws(Exception::class)
    open fun clone(): Any? {
        println("TWB:clone")
        return clone(this)
    }

    fun equals(o: java.lang.Object): Boolean {
        return this === o
    }

    @Throws(Throwable::class)
    protected fun finalize() {
    }

    override fun hashCode(): Int {
        return 1
    }

    fun notify() {

    }

    fun notifyAll() {

    }

    override fun toString(): String {
        return StringUtil.getInstance().EMPTY_STRING
    }


    @Throws(Exception::class)
    //external fun wait(milliseconds: Long = 0)
    fun wait(milliseconds: Long = 0) {

    }

    @Throws(Exception::class)
    fun wait(milliseconds: Long, nanoseconds: Int) {
        var milliseconds = milliseconds
        if (nanoseconds != 0) {
            ++milliseconds
        }
        this.wait(milliseconds)
    }

    fun getClass():KClass<*> {
        var clazz: KClass<*> = this::class
        return clazz;
    }

    companion object {
        fun clone(o: java.lang.Object): java.lang.Object {
            return o
        }
    }
}
