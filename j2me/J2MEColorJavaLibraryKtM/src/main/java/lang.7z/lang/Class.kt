package java.lang

class Class<T> {
}