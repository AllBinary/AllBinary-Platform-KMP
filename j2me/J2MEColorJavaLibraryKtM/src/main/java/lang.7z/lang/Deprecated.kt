
        /* Generated Code Do Not Modify */
        package java.lang




        open public class Deprecated
            : java.lang.Object
         {
        

            //Auto Generated
            private constructor() : super()
            {
            }            
        
}


