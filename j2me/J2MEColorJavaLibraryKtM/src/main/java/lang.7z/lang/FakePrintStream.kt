package java.lang

import kotlinx.cinterop.ExperimentalForeignApi
import platform.posix.fflush
import platform.posix.stdout

open class FakePrintStream {

    open fun print(o: Any) {
        kotlin.io.print(o)
    }

    //@OptIn(ExperimentalForeignApi::class)
    open fun println(o: Any) {
        kotlin.io.println(o)
        //fflush(stdout)
    }

}