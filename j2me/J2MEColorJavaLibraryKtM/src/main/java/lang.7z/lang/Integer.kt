/* Copyright (c) 2008-2015, Avian Contributors

   Permission to use, copy, modify, and/or distribute this software
   for any purpose with or without fee is hereby granted, provided
   that the above copyright notice and this permission notice appear
   in all copies.

   There is NO WARRANTY for this software.  See license.txt for
   details. */
package java.lang

open class Integer : Number, Comparable<Integer?> {
    private val value: Int

    constructor(value: Int) {
        this.value = value
    }

    constructor(s: String?) {
        this.value = s!!.toInt()
    }

    constructor(s: String?, radix: Int) {
        this.value = s!!.toInt(radix)
    }

    fun equals(o: Object?): Boolean {
        if (o == null) return false
        val n = o as Number
        //if (n.getType() === 3) {
        if(o is Integer) {
            return (o as Integer).value == value
        }
        return false
    }

    override fun hashCode(): Int {
        return value
    }

    fun compareTo(other: Integer): Int {
        return value - other.value
    }

    fun compare(value: Int): Int {
        return this.value - value
    }

    override fun toString(): String {
        return value.toString()
    }

    fun byteValue(): Byte {
        return value.toByte()
    }

    fun shortValue(): Short {
        return value.toShort()
    }

    fun intValue(): Int {
        return value
    }

    fun longValue(): Long {
        return value.toLong()
    }

    fun floatValue(): Float {
        return value.toFloat()
    }

    fun doubleValue(): Double {
        return value.toDouble()
    }

    val type: Int
        get() = 3

    override fun compareTo(other: Integer?): Int {
        TODO("Not yet implemented")
    }

    override fun toDouble(): Double {
        TODO("Not yet implemented")
    }

    override fun toFloat(): Float {
        TODO("Not yet implemented")
    }

    override fun toLong(): Long {
        TODO("Not yet implemented")
    }

    override fun toInt(): Int {
        TODO("Not yet implemented")
    }

    override fun toShort(): Short {
        TODO("Not yet implemented")
    }

    override fun toByte(): Byte {
        TODO("Not yet implemented")
    }

    companion object {
        //val TYPE: Class? = avian.Classes.forCanonicalName("I")

        const val MIN_VALUE: Int = -0x80000000
        const val MAX_VALUE: Int = 0x7FFFFFFF

        fun valueOf(s: String?, radix: Int): Integer {
            return Integer(s, radix)
        }

//        fun valueOf(value: Int): Integer {
//            return value
//        }

//        fun valueOf(value: String?): Integer {
//            return value.toInt()
//        }

        fun compare(value: Int, value2: Int): Int {
            return value - value2
        }

        fun toString(v: Int, radix: Int): String {
            return v.toString()
        }

        fun toString(v: Int): String {
            return v.toString(10)
        }

        fun toHexString(v: Int): String {
            return v.toString(16)
        }

        fun toOctalString(v: Int): String {
            return v.toString(8)
        }

        fun toBinaryString(v: Int): String {
            return v.toString(2)
        }

        fun signum(v: Int): Int {
            if (v == 0) return 0
            else if (v > 0) return 1
            else return -1
        }

        // See http://graphics.stanford.edu/~seander/bithacks.html#CountBitsSetParallel
        fun bitCount(v: Int): Int {
            var v = v
            v = v - ((v shr 1) and 0x55555555)
            v = (v and 0x33333333) + ((v shr 2) and 0x33333333)
            return ((v + (v shr 4) and 0xF0F0F0F) * 0x1010101) shr 24
        }

        fun reverseBytes(v: Int): Int {
            val byte3 = v ushr 24
            val byte2 = (v ushr 8) and 0xFF00
            val byte1 = (v shl 8) and 0xFF00
            val byte0 = v shl 24
            return (byte0 or byte1 or byte2 or byte3)
        }

        fun parseInt(s: String?): Int {
            return s!!.toInt()
        }

        fun parseInt(s: String?, radix: Int): Int {
            return s!!.toInt(radix)
        }

        fun numberOfLeadingZeros(i: Int): Int {
            // See nlz5 at http://www.hackersdelight.org/hdcodetxt/nlz.c.txt
            var i = i
            i = i or (i shr 1)
            i = i or (i shr 2)
            i = i or (i shr 4)
            i = i or (i shr 8)
            i = i or (i shr 16)
            return bitCount(i.inv())
        }
    }
}
