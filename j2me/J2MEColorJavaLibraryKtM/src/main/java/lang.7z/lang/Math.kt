
        
        /* Copyright (c) 2008-2015, Avian Contributors     Permission to use, copy, modify, and/or distribute this software    for any purpose with or without fee is hereby granted, provided    that the above copyright notice and this permission notice appear    in all copies.     There is NO WARRANTY for this software.  See license.txt for    details. 
        */
    
        /* Generated Code Do Not Modify */
        package java.lang



        
        import java.lang.Object;
        import kotlin.reflect.KClass
        
//import java.util.Random


        open public class Math
            : Object
         {
        

        companion object {

//    val E: Double =
//                //Otherwise - initializer - DoubleLiteralExpr
//    val PI: Double =
//                //Otherwise - initializer - DoubleLiteralExpr
//Static    val random: Random = Random()
//
//open fun max(a: Double, b: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Double
//        {
//
//
//                    var a = a
//
//
//                    var b = b
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
fun min(a: Double, b: Double)
        //nullable = true from not(false or (false and false)) = true
: Double
        {


                    var a = a


                    var b = b



                        //if statement needs to be on the same line and ternary does not work the same way.
                        return a
                            //()


        }
//
//fun max(a: Float, b: Float)
//        //nullable = true from not(false or (false and false)) = true
//: Float
//        {
//
//
//                    var a = a
//
//
//                    var b = b
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
//open fun min(a: Float, b: Float)
//        //nullable = true from not(false or (false and false)) = true
//: Float
//        {
//
//
//                    var a = a
//
//
//                    var b = b
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
//open fun max(a: Long, b: Long)
//        //nullable = true from not(false or (false and false)) = true
//: Long
//        {
//
//
//                    var a = a
//
//
//                    var b = b
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
//open fun min(a: Long, b: Long)
//        //nullable = true from not(false or (false and false)) = true
//: Long
//        {
//
//
//                    var a = a
//
//
//                    var b = b
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
//open fun max(a: Int, b: Int)
//        //nullable = true from not(false or (false and false)) = true
//: Int
//        {
//
//
//                    var a = a
//
//
//                    var b = b
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
open fun min(a: Int, b: Int)
        //nullable = true from not(false or (false and false)) = true
: Int
        {


                    var a = a


                    var b = b




                        //if statement needs to be on the same line and ternary does not work the same way.
            //kotlin.math.min(a, b)
            if(a <= b) { return a } else { return b }
                            //()


        }
//
//open fun abs(v: Int)
//        //nullable = true from not(false or (false and false)) = true
//: Int
//        {
//
//
//                    var v = v
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
//open fun abs(v: Long)
//        //nullable = true from not(false or (false and false)) = true
//: Long
//        {
//
//
//                    var v = v
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
//open fun abs(v: Float)
//        //nullable = true from not(false or (false and false)) = true
//: Float
//        {
//
//
//                    var v = v
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
//open fun abs(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Double
//        {
//
//
//                    var v = v
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            ()
//
//
//        }
//
//open fun round(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Long
//        {
//
//
//                    var v = v
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            //Otherwise - expression - CastExpr
//
//        }
//
//open fun round(v: Float)
//        //nullable = true from not(false or (false and false)) = true
//: Int
//        {
//
//
//                    var v = v
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            //Otherwise - expression - CastExpr
//
//        }
//
//open fun signum(d: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Double
//        {
//
//
//                    var d = d
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return if(d > 0) {
//
//                             + 1.0
//
//                            } else {
//
//                                        //Otherwise - expression - elseExpr - ConditionalExpr
//                            }
//
//
//
//        }
//
//open fun signum(f: Float)
//        //nullable = true from not(false or (false and false)) = true
//: Float
//        {
//
//
//                    var f = f
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return if(f > 0) {
//
//                             + 1.0f
//
//                            } else {
//
//                                        //Otherwise - expression - elseExpr - ConditionalExpr
//                            }
//
//
//
//        }
//
//open fun random()
//        //nullable = true from not(false or (false and true)) = true
//: Double
//        {
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return nextDouble()!!
//
//
//        }
//
//    private val DEGREES_TO_RADIANS: Double =
//                //Otherwise - initializer - DoubleLiteralExpr
//open fun toRadians(angdeg: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Double
//        {
//
//
//                    var angdeg = angdeg
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return angdeg * DEGREES_TO_RADIANS
//
//        }
//
//open fun floor(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun ceil(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun exp(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun log(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun cos(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun sin(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun tan(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun cosh(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun sinh(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun tanh(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun acos(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun asin(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun atan(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun atan2(y: Double, x: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun sqrt(v: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Doubleopen fun pow(v: Double, e: Double)
//        //nullable = true from not(false or (false and false)) = true
//: Double
//
        }
        

//Static
private constructor()
            : super()
        
        {
            
        }
        


}


