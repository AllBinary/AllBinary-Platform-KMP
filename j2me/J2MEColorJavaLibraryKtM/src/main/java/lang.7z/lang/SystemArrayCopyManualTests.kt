package java.lang

import kotlin.jvm.JvmStatic


object SystemArrayCopyManualTest {

    //fun main(args: Array<String>) {
    fun test() {
        testCopyIntArray()
        testCopyPartialArray()
        testCopyToSameArray()
        testCopyObjectArray()
        testArrayStoreException()
        testIndexOutOfBoundsException()
        testNullPointerException()
        testZeroLengthCopy()
    }

    fun testCopyIntArray() {
        val source = intArrayOf(1, 2, 3, 4, 5)
        val destination = IntArray(5)
        System.arraycopy(source, 0, destination, 0, source.size)

        println("testCopyIntArray: " + source.contentEquals(destination))
    }

    fun testCopyPartialArray() {
        val source = intArrayOf(10, 20, 30, 40, 50)
        val destination = intArrayOf(0, 0, 0, 0, 0)
        System.arraycopy(source, 1, destination, 2, 2)

        val expected = intArrayOf(0, 0, 20, 30, 0)
        println("testCopyPartialArray: " + expected.contentEquals(destination))
    }

    fun testCopyToSameArray() {
        val array = intArrayOf(1, 2, 3, 4, 5)
        System.arraycopy(array, 0, array, 1, 4)

        val expected = intArrayOf(1, 1, 2, 3, 4)
        println("testCopyToSameArray: " + expected.contentEquals(array) + array.contentToString())
    }

    fun testCopyObjectArray() {
        val source = arrayOf<String?>("apple", "banana", "cherry")
        val destination = kotlin.arrayOfNulls<String>(3)
        System.arraycopy(source, 0, destination, 0, 3)

        println("testCopyObjectArray: " + source.contentEquals(destination))
    }

    fun testArrayStoreException() {
        val source: Array<String> = arrayOf<String>("hello", "world")
        val destination: Array<Int?> = kotlin.arrayOfNulls<Int>(2)

        try {
            System.arraycopy(source, 0, destination, 0, 2)
            println("testArrayStoreException: FAILED (no exception)")
        } catch (e: Exception) {
            println("testArrayStoreException: PASSED")
        }
    }

    fun testIndexOutOfBoundsException() {
        val source = intArrayOf(1, 2, 3)
        val destination = IntArray(3)

        try {
            System.arraycopy(source, 0, destination, 1, 3)
            println("testIndexOutOfBoundsException: FAILED (no exception)")
        } catch (e: Exception) {
            println("testIndexOutOfBoundsException: PASSED")
        }
    }

    fun testNullPointerException() {
        val source: IntArray? = null
        val destination = IntArray(3)

        try {
            System.arraycopy(source, 0, destination, 0, 3)
            println("testNullPointerException: FAILED (no exception)")
        } catch (e: Exception) {
            println("testNullPointerException: PASSED")
        }
    }

    fun testZeroLengthCopy() {
        val source = intArrayOf(1, 2, 3)
        val destination = intArrayOf(4, 5, 6)
        System.arraycopy(source, 1, destination, 1, 0) // No effect

        val expected = intArrayOf(4, 5, 6)
        println("testZeroLengthCopy: " + expected.contentEquals(destination))
    }
}
