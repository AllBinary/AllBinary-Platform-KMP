
        
        /* Copyright (c) 2008-2015, Avian Contributors     Permission to use, copy, modify, and/or distribute this software    for any purpose with or without fee is hereby granted, provided    that the above copyright notice and this permission notice appear    in all copies.     There is NO WARRANTY for this software.  See license.txt for    details. 
        */
    
        /* Generated Code Do Not Modify */
        package java.lang


        import kotlin.time.TimeSource
        
        import java.lang.Object;
        import kotlin.Any
        import kotlin.Array
        import kotlin.reflect.KClass
        
//import java.io.PrintStream
//import java.io.InputStream
//import java.io.BufferedInputStream
//import java.io.BufferedOutputStream
//import java.io.FileInputStream
//import java.io.FileOutputStream
//import java.io.FileDescriptor
//import java.util.Map
//import java.util.Hashtable
//import java.util.Properties


        open public class System
            : Object
         {
        

        companion object {

//NanoTime    val BaseInMillis: Long = currentTimeMillis()
//Static    val properties: Properties? = makeProperties()
//    private val environment: Map?
//    private val securityManager: SecurityManager?
      val out: FakePrintStream = FakePrintStream()
//    val out: PrintStream = PrintStream(BufferedOutputStream(FileOutputStream(FileDescriptor.out)
//                        )
//                        true)
//
//    val err: PrintStream = PrintStream(BufferedOutputStream(FileOutputStream(FileDescriptor.err)
//                        )
//                        true)
//
//    val in: InputStream = BufferedInputStream(FileInputStream(FileDescriptor.in)
//                        )
fun arraycopy(src: Any?, srcOffset: Int, dst: Any?, dstOffset: Int, length: Int)                //native - START
{

    //arraycopy Impl
    if(src is CharArray) {

        var srcArray = src as CharArray
        var dstArray = dst as CharArray

        for(index in 0 until length) {
            dstArray[index + dstOffset] = srcArray[index + srcOffset];
        }

    } else if(src is IntArray) {

        var dstArray = dst as IntArray
        var srcArray = this.getSourceIntArray(src, dstArray)

        for(index in 0 until length) {
            dstArray[index + dstOffset] = srcArray[index + srcOffset];
        }

    } else {

        var dstArray = dst as Array<Any>
        var srcArray = this.getSourceArray(src as Array<Any>, dstArray)

        for(index in 0 until length) {
            dstArray[index + dstOffset] = srcArray[index + srcOffset];
        }

    }

}
            fun getSourceIntArray(src: IntArray, dst: IntArray): IntArray {

                if(src == dst) {
                    return src.copyOf();
                } else {
                    return src;
                }

            }

            fun getSourceArray(src: Array<Any>, dst: Array<Any>): Array<Any> {

                if(src == dst) {
                    return src.copyOf();
                } else {
                    return src;
                }

            }

        //nullable = true from not(false or (false and false)) = true
fun getProperty(name: String?)
        //nullable = true from not(false or (false and false)) = true
: String?
        {


                    var name = name



                        //if statement needs to be on the same line and ternary does not work the same way.
                        return name
                            //Otherwise - expression - CastExpr

        }
//
//open fun getProperty(name: String?, defaultValue: String?)
//        //nullable = true from not(false or (false and false)) = true
//: String?
//        {
//
//
//                    var name = name
//
//
//                    var defaultValue = defaultValue
//
//
//
//                        var result: String? = getProperty(name)
//
//
//                        if(result ==
//                                    null
//                                )
//
//                                    {
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return defaultValue
//
//                                    }
//
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return result
//
//        }
//
//open fun setProperty(name: String?, value: String?)
//        //nullable = true from not(false or (false and false)) = true
//: String?
//        {
//
//
//                    var name = name
//
//
//                    var value = value
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return
//                            //Otherwise - expression - CastExpr
//
//        }
//
//open fun getProperties()
//        //nullable = true from not(false or (false and true)) = true
//: Properties?
//        {
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return Static.properties
//
//        }
//
//open fun makeProperties()
//        //nullable = true from not(false or (false and true)) = true
//: Properties?
//        {
//
//
//
//                        var properties: Properties? = Properties()
//
//
//                    //Otherwise - statement - ForEachStmt
//
//                    //Otherwise - statement - ForEachStmt
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return properties
//
//        }
//
//open fun getNativeProperties()
//        //nullable = true from not(false or (false and true)) = true
//: Array<String?>
//                    open fun getVMProperties()
//        //nullable = true from not(false or (false and true)) = true
//: Array<String?>
                    fun currentTimeMillis()
        //nullable = true from not(false or (false and true)) = true
//: Long open fun identityHashCode(o: Any?)
        //nullable = true from not(false or (false and false)) = true
//: Int open fun nanoTime()
        //nullable = true from not(false or (false and true)) = true
: Long
        {

            val timeSource = TimeSource.Monotonic
            val mark1 = timeSource.markNow()

                        //if statement needs to be on the same line and ternary does not work the same way.
                        //return (currentTimeMillis() - mark1) * 1000000
            return mark1.elapsedNow().inWholeMilliseconds

        }
//
//open fun mapLibraryName(name: String?)
//        //nullable = true from not(false or (false and false)) = true
//: String?
//        {
//
//
//                    var name = name
//
//
//                        if(name !=
//                                    null
//                                )
//
//                                    {
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return doMapLibraryName(name)!!
//
//
//                                    }
//
//                        else {
//
//
//
//                            throw NullPointerException()
//
//
//                        }
//
//
//        }
//
//open fun doMapLibraryName(name: String?)
//        //nullable = true from not(false or (false and false)) = true
//: String?open fun load(path: String?)
//        //nullable = true from not(false or (false and false)) = true
//
//        {
//
//
//                    var path = path
//ClassLoader.load(path, ClassLoader.getCaller(), false)
//
//
//        }
//
//open fun loadLibrary(name: String?)
//        //nullable = true from not(false or (false and false)) = true
//
//        {
//
//
//                    var name = name
//ClassLoader.load(name, ClassLoader.getCaller(), true)
//
//
//        }
//
//open fun gc()
//        //nullable = true from not(false or (false and true)) = true
//
//        {
//            Runtime.getRuntime()!!.gc()
//
//
//        }
//
//open fun exit(code: Int)
//        //nullable = true from not(false or (false and false)) = true
//
//        {
//
//
//                    var code = code
//Runtime.getRuntime()!!.exit(code)
//
//
//        }
//
//open fun getSecurityManager()
//        //nullable = true from not(false or (false and true)) = true
//: SecurityManager?
//        {
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return securityManager
//
//        }
//
//open fun setSecurityManager(securityManager: SecurityManager?)
//        //nullable = true from not(false or (false and false)) = true
//
//        {
//
//
//                    var securityManager = securityManager
//System.securityManager =
//                                    securityManager
//
//        }
//
//
//                            @Throws(NullPointerException::class)
//
//                            @Throws(SecurityException::class)
//                        open fun getenv(name: String?)
//        //nullable = true from not(false or (false and false)) = true
//: String?
//        {
//
//
//                    var name = name
//
//
//                        if(getSecurityManager() !=
//                                    null
//                                )
//
//                                    {
//                                    getSecurityManager()!!.checkPermission(RuntimePermission(
//                                    //Otherwise - left - StringLiteralExpr + name)
//                        )
//
//
//                                    }
//
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return get(name)!!
//
//
//        }
//
//
//                            @Throws(SecurityException::class)
//                        open fun getenv()
//        //nullable = true from not(false or (false and true)) = true
//: Map?
//        {
//
//
//                        if(getSecurityManager() !=
//                                    null
//                                )
//
//                                    {
//                                    getSecurityManager()!!.checkPermission(RuntimePermission(
//                            "getenv.*")
//                        )
//
//
//                                    }
//
//
//
//                        if(environment ==
//                                    null
//                                )
//
//                                    {
//
//
//
//                        var vars: Array<String?>
//                     = getEnvironment()
//environment =
//                                    Hashtable(vars!!.size)
//
//
//                    //Otherwise - statement - ForEachStmt
//
//                                    }
//
//
//
//
//                        //if statement needs to be on the same line and ternary does not work the same way.
//                        return environment
//
//        }
//
//open fun getEnvironment()
//        //nullable = true from not(false or (false and true)) = true
//: Array<String?>
//
//
//        }
//
        }

            //Auto Generated
            private constructor() : super()
            {
            }
//        NanoTime
//Static



}


